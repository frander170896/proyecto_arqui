<html>
 	<head>
  		<meta http-equiv="Refresh" content="0;url=http://localhost:8095/Proyectos/Proyecto_arqui/Proyecto_Arquitectura/interface">
 	</head>
</html>